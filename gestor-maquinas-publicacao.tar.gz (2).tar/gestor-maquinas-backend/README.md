# Gestor Máquinas — base online segura inicial

API simples para máquinas, clientes, manutenções e consumíveis, com SQLite e autenticação por token com validade de 24 horas.

## Configuração

1. Copie `.env.example` para as variáveis do servidor.
2. Defina uma palavra-passe forte e uma chave secreta longa.
3. Execute `python3 server.py`.
4. Publique somente atrás de HTTPS.

A rota `POST /login` recebe `{ "user": "...", "password": "..." }` e devolve um token. As rotas `/machines`, `/clients`, `/maintenance` e `/stock` exigem `Authorization: Bearer TOKEN`.

Antes de produção, configurar HTTPS, backups e limites de acesso do servidor.
