# Publicação segura

O backend está preparado para publicação num serviço Docker, incluindo Render.

## Configuração necessária

- `GESTOR_ADMIN_USER`: `julio`
- `GESTOR_ADMIN_PASSWORD`: uma palavra-passe forte escolhida pelo administrador
- `GESTOR_TOKEN_SECRET`: uma chave longa e aleatória

Depois da publicação, colocar o endereço HTTPS da API no botão **Servidor** do aplicativo. Não usar o endereço HTTP local em produção.

O armazenamento SQLite precisa de disco persistente, já incluído no `render.yaml`.
